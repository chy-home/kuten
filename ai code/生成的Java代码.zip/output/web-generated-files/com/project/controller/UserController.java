package com.project.controller;

import com.project.dto.UserReqDTO;
import com.project.dto.UserResDTO;
import com.project.service.UserService;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * 自動生成 Controller。
 */
@Validated
@RestController
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * ユーザー情報照会。
     */
    @PostMapping("/api/user/query")
    public UserResDTO query(@Valid @RequestBody UserReqDTO request) {
        return userService.query(request);
    }

    /**
     * 単一ユーザー登録。
     */
    @PostMapping("/api/user/insert")
    public UserResDTO insert(@Valid @RequestBody UserReqDTO request) {
        return userService.insert(request);
    }

    /**
     * ユーザー一括登録。
     */
    @PostMapping("/api/user/batchInsert")
    public List<UserResDTO> batchInsert(@Valid @RequestBody List<UserReqDTO> requestList) {
        return userService.batchInsert(requestList);
    }

    /**
     * ユーザー情報更新。
     */
    @PostMapping("/api/user/update")
    public UserResDTO update(@Valid @RequestBody UserReqDTO request) {
        return userService.update(request);
    }

}
