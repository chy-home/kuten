package com.project.dao;

import com.project.entity.UserEntity;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 自動生成 Dao。
 */
public interface UserDao {

    List<UserEntity> query(@Param("entity") UserEntity entity);

    int insert(@Param("entity") UserEntity entity);

    int batchInsert(@Param("entityList") List<UserEntity> entityList);

    int update(@Param("entity") UserEntity entity);

}
