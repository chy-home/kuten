package com.project.service.impl;

import com.project.dto.UserReqDTO;
import com.project.dto.UserResDTO;
import com.project.entity.UserEntity;
import com.project.dao.UserDao;
import com.project.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 自動生成 ServiceImpl。
 */
@Service
public class UserServiceImpl implements UserService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

    private final UserDao userDao;

    public UserServiceImpl(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public UserResDTO query(UserReqDTO request) {
        LOGGER.info("Start method: queryUser");
        if (request == null) {
        throw new IllegalArgumentException("request must not be null");
        }
        UserEntity userEntity = userDao.queryByUserId(request.getUserId());
        List\u003cUserEntity\u003e userList = userDao.queryAllUsers();
        UserResDTO response = toResponseDto(userEntity, userList);
        return response;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    public UserResDTO insert(UserReqDTO request) {
        LOGGER.info("Start method: insertUser");
        if (request == null) {
        throw new IllegalArgumentException("request must not be null");
        }
        UserEntity entity = toEntity(request);
        int result = userDao.insert(entity);
        return toResponseDto(result);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    public List<UserResDTO> batchInsert(List<UserReqDTO> requestList) {
        LOGGER.info("Start method: batchInsert");
        if (requestList == null || requestList.isEmpty()) {
        throw new IllegalArgumentException("requestList must not be null or empty");
        }
        for (UserReqDTO req : requestList) {
        UserEntity entity = toEntity(req);
        }
        return toResponseDto();
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
    public UserResDTO update(UserReqDTO request) {
        LOGGER.info("Start method: updateUser");
        if (request == null) {
        throw new IllegalArgumentException("request must not be null");
        }
        UserEntity entity = toEntity(request);
        int result = userDao.update(entity);
        return toResponseDto(result);
    }

    private UserEntity toEntity(UserReqDTO request) {
        UserEntity entity = new UserEntity();
        entity.setUserId(request.getUserId());
        entity.setUserName(request.getUserName());
        entity.setUserAge(request.getUserAge());
        return entity;
    }

    private UserResDTO toResponseDto() {
        UserResDTO response = new UserResDTO();
        response.setResultCode("00");
        response.setResultMsg("success");
        response.setUserInfo(null);
        response.setUserList(null);
        return response;
    }
}
