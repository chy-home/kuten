package com.project.service;

import com.project.dto.UserReqDTO;
import com.project.dto.UserResDTO;

import java.util.List;

/**
 * 自動生成 Service。
 */
public interface UserService {

    UserResDTO query(UserReqDTO request);

    UserResDTO insert(UserReqDTO request);

    List<UserResDTO> batchInsert(List<UserReqDTO> requestList);

    UserResDTO update(UserReqDTO request);

}
