package com.project.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * 自動生成 DTO/Entity。
 */
public class UserReqDTO {

    @NotNull
    @Size(max = 20)
    private String userId;

    @NotNull
    @Size(max = 50)
    private String userName;

    private Integer userAge;

    private List<UserReqDTO> userList;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getUserAge() {
        return userAge;
    }

    public void setUserAge(Integer userAge) {
        this.userAge = userAge;
    }

    public List<UserReqDTO> getUserList() {
        return userList;
    }

    public void setUserList(List<UserReqDTO> userList) {
        this.userList = userList;
    }

}
