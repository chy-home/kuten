package com.project.dto;

import com.project.entity.UserEntity;
import java.util.List;

/**
 * 自動生成 DTO/Entity。
 */
public class UserResDTO {

    private String resultCode;

    private String resultMsg;

    private UserEntity userInfo;

    private List<UserEntity> userList;

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public UserEntity getUserInfo() {
        return userInfo;
    }

    public void setUserInfo(UserEntity userInfo) {
        this.userInfo = userInfo;
    }

    public List<UserEntity> getUserList() {
        return userList;
    }

    public void setUserList(List<UserEntity> userList) {
        this.userList = userList;
    }

}
