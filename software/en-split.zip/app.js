const sourceText = document.getElementById("sourceText");
const resultText = document.getElementById("resultText");
const summary = document.getElementById("summary");
const txtFile = document.getElementById("txtFile");
const extractButton = document.getElementById("extractButton");
const clearButton = document.getElementById("clearButton");
const copyButton = document.getElementById("copyButton");
const downloadButton = document.getElementById("downloadButton");
const minWordLength = document.getElementById("minWordLength");
const minPhraseFrequency = document.getElementById("minPhraseFrequency");
const excludeStopwords = document.getElementById("excludeStopwords");
const includePhrases = document.getElementById("includePhrases");
const enableOnlineLookup = document.getElementById("enableOnlineLookup");
const onlineProvider = document.getElementById("onlineProvider");
const translationEndpoint = document.getElementById("translationEndpoint");
const translationApiKey = document.getElementById("translationApiKey");

const stopwords = new Set([
  "a", "an", "and", "are", "as", "at", "be", "been", "being", "but", "by", "for", "from",
  "had", "has", "have", "he", "her", "here", "hers", "him", "his", "i", "if", "in", "into",
  "is", "it", "its", "me", "my", "of", "on", "or", "our", "ours", "she", "that", "the",
  "their", "theirs", "them", "there", "they", "this", "those", "to", "too", "us", "was",
  "we", "were", "what", "when", "where", "which", "who", "will", "with", "you", "your", "yours"
]);

let ipaDictionary = {}

let meaningDictionary = {}

let phraseMeaningDictionary = {}

const onlineMeaningCache = new Map();
let dictionariesReady = false;
let dictionaryLoadPromise = null;

onlineProvider.addEventListener("change", syncOnlineProviderFields);
syncOnlineProviderFields();

txtFile.addEventListener("change", async (event) => {
  const [file] = event.target.files;
  if (!file) {
    return;
  }

  const text = await file.text();
  sourceText.value = text;
});

extractButton.addEventListener("click", async () => {
  const text = sourceText.value.trim();
  if (!text) {
    summary.textContent = "请输入文本或先上传 TXT 文件。";
    resultText.value = "";
    return;
  }

  try {
    summary.textContent = "正在加载离线词典...";
    await ensureDictionariesLoaded();
  } catch (error) {
    summary.textContent = error.message || "离线词典加载失败。";
    resultText.value = "";
    return;
  }

  const extraction = extractVocabulary(text, {
    minLength: Number(minWordLength.value) || 3,
    minPhraseHits: Number(minPhraseFrequency.value) || 2,
    excludeCommonWords: excludeStopwords.checked,
    includePhraseExtraction: includePhrases.checked
  });

  if (enableOnlineLookup.checked) {
    summary.textContent = "正在提取并补充在线释义...";
    await enrichMeaningsOnline(extraction, {
      provider: onlineProvider.value,
      translationEndpoint: translationEndpoint.value.trim(),
      apiKey: translationApiKey.value.trim()
    });
  }

  resultText.value = buildReport(extraction);
  summary.textContent = `已提取 ${extraction.words.length} 个单词，${extraction.phrases.length} 个短语。`;
});

clearButton.addEventListener("click", () => {
  sourceText.value = "";
  resultText.value = "";
  txtFile.value = "";
  summary.textContent = "已清空";
});

copyButton.addEventListener("click", async () => {
  if (!resultText.value.trim()) {
    summary.textContent = "当前没有可复制的结果。";
    return;
  }

  try {
    if (!navigator.clipboard || !window.isSecureContext) {
      throw new Error("clipboard-unavailable");
    }

    await navigator.clipboard.writeText(resultText.value);
    summary.textContent = "结果已复制到剪贴板。";
  } catch (error) {
    resultText.focus();
    resultText.select();
    summary.textContent = "浏览器限制了自动复制，已帮你选中文本，可直接 Ctrl/Cmd+C。";
  }
});

downloadButton.addEventListener("click", () => {
  if (!resultText.value.trim()) {
    summary.textContent = "当前没有可下载的结果。";
    return;
  }

  const blob = new Blob([resultText.value], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "extracted-vocabulary.txt";
  anchor.click();
  URL.revokeObjectURL(url);
  summary.textContent = "已下载 TXT 结果。";
});

function extractVocabulary(text, options) {
  const normalizedText = text.replace(/\r\n/g, "\n");
  const tokens = normalizeTokens(normalizedText);
  const wordCounts = new Map();
  const wordContexts = new Map();

  for (const [index, token] of tokens.entries()) {
    if (token.length < options.minLength) {
      continue;
    }

    if (options.excludeCommonWords && stopwords.has(token)) {
      continue;
    }

    wordCounts.set(token, (wordCounts.get(token) || 0) + 1);
    pushContext(wordContexts, token, collectContext(tokens, index));
  }

  const words = [...wordCounts.entries()]
    .sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]))
    .map(([word, count]) => ({
      word,
      count,
      ipa: getIpa(word),
      meaning: getMeaning(word, wordContexts.get(word) || [], "word")
    }));

  const phrases = options.includePhraseExtraction
    ? extractPhrases(normalizedText, options.minPhraseHits)
    : [];

  return { words, phrases };
}

function normalizeTokens(text) {
  const matches = text.toLowerCase().match(/[a-z]+(?:['-][a-z]+)*/g);
  if (!matches) {
    return [];
  }

  return matches
    .map((item) => item.replace(/^['-]+|['-]+$/g, ""))
    .filter(Boolean);
}

async function ensureDictionariesLoaded() {
  if (dictionariesReady) {
    return;
  }

  if (!dictionaryLoadPromise) {
    dictionaryLoadPromise = loadDictionaries();
  }

  await dictionaryLoadPromise;
  dictionariesReady = true;
}

async function loadDictionaries() {
  try {
    const manifestResponse = await fetch("./data/dictionary-manifest.json");
    if (!manifestResponse.ok) {
      throw new Error("词典清单加载失败。");
    }

    const manifest = await manifestResponse.json();
    const [ipaData, meaningData, phraseData] = await Promise.all([
      fetchJson(manifest.dictionaries.ipaDictionary),
      fetchJson(manifest.dictionaries.meaningDictionary),
      fetchJson(manifest.dictionaries.phraseMeaningDictionary)
    ]);

    ipaDictionary = ipaData;
    meaningDictionary = meaningData;
    phraseMeaningDictionary = phraseData;
  } catch (error) {
    dictionaryLoadPromise = null;
    if (location.protocol === "file:") {
      throw new Error("离线词典采用独立 JSON 文件，请通过静态文件服务打开，例如执行 python3 -m http.server 8080。");
    }
    throw error;
  }
}

async function fetchJson(path) {
  const response = await fetch(path);
  if (!response.ok) {
    throw new Error(`词典文件加载失败: ${path}`);
  }

  return response.json();
}

function extractPhrases(text, minHits) {
  const phraseCounts = new Map();
  const phraseContexts = new Map();
  const segments = text
    .toLowerCase()
    .split(/[\n.?!;:]+/)
    .map((part) => normalizeTokens(part))
    .filter((part) => part.length > 1);

  for (const segment of segments) {
    for (let size = 2; size <= 3; size += 1) {
      for (let index = 0; index <= segment.length - size; index += 1) {
        const slice = segment.slice(index, index + size);
        if (!isUsefulPhrase(slice)) {
          continue;
        }

        const phrase = slice.join(" ");
        phraseCounts.set(phrase, (phraseCounts.get(phrase) || 0) + 1);
        pushContext(phraseContexts, phrase, collectContext(segment, index, size));
      }
    }
  }

  return [...phraseCounts.entries()]
    .filter(([, count]) => count >= minHits)
    .sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]))
    .map(([phrase, count]) => ({
      phrase,
      count,
      ipa: phrase.split(" ").map(getIpa).join(" "),
      meaning: getMeaning(phrase, phraseContexts.get(phrase) || [], "phrase")
    }));
}

function isUsefulPhrase(words) {
  if (words.every((word) => stopwords.has(word))) {
    return false;
  }

  if (stopwords.has(words[0]) || stopwords.has(words[words.length - 1])) {
    return false;
  }

  return words.some((word) => word.length >= 4);
}

function buildReport(extraction) {
  const lines = [];
  lines.push("英文单词与短语提取结果");
  lines.push(`生成时间: ${new Date().toLocaleString()}`);
  lines.push("");

  lines.push("[单词]");
  if (extraction.words.length === 0) {
    lines.push("无");
  } else {
    extraction.words.forEach((item, index) => {
      lines.push(`${index + 1}. ${item.word} ${item.ipa} ${item.meaning}`);
    });
  }

  lines.push("");
  lines.push("[短语]");
  if (extraction.phrases.length === 0) {
    lines.push("无");
  } else {
    extraction.phrases.forEach((item, index) => {
      lines.push(`${index + 1}. ${item.phrase} ${item.ipa} ${item.meaning}`);
    });
  }

  return lines.join("\n");
}

function getIpa(word) {
  if (ipaDictionary[word]) {
    return ipaDictionary[word];
  }

  return `/${guessIpa(word)}/`;
}

function getMeaning(term, contexts, type) {
  const normalizedTerm = term.toLowerCase();
  if (type === "phrase") {
    const directPhraseMeaning = phraseMeaningDictionary[normalizedTerm];
    if (directPhraseMeaning) {
      return directPhraseMeaning;
    }

    const normalizedPhrase = lemmatizePhrase(normalizedTerm);
    if (normalizedPhrase !== normalizedTerm && phraseMeaningDictionary[normalizedPhrase]) {
      return phraseMeaningDictionary[normalizedPhrase];
    }

    return normalizedTerm
      .split(" ")
      .map((word) => getMeaning(word, contexts, "word"))
      .join(" / ");
  }

  const lemma = lemmatizeWord(normalizedTerm);
  const entry = meaningDictionary[normalizedTerm] || meaningDictionary[lemma];
  if (typeof entry === "string") {
    return entry;
  }

  if (Array.isArray(entry)) {
    const contextWords = new Set(
      contexts.flatMap((context) => normalizeTokens(context))
    );

    let bestMeaning = entry[0].zh;
    let bestScore = -1;
    for (const candidate of entry) {
      const score = (candidate.tags || []).reduce(
        (total, tag) => total + (contextWords.has(tag) ? 1 : 0),
        0
      );
      if (score > bestScore) {
        bestScore = score;
        bestMeaning = candidate.zh;
      }
    }

    return bestMeaning;
  }

  return "待补充释义";
}

function lemmatizePhrase(phrase) {
  return phrase
    .split(" ")
    .map((word) => lemmatizeWord(word))
    .join(" ");
}

function lemmatizeWord(word) {
  const irregulars = {
    analyses: "analysis",
    agendas: "agenda",
    APIs: "api",
    api: "api",
    apps: "app",
    businesses: "business",
    cases: "case",
    children: "child",
    clients: "client",
    companies: "company",
    decisions: "decision",
    deliverables: "deliverable",
    discussions: "discussion",
    documents: "document",
    files: "file",
    findings: "finding",
    issues: "issue",
    minutes: "minutes",
    meetings: "meeting",
    men: "man",
    messages: "message",
    metrics: "metric",
    people: "person",
    priorities: "priority",
    projects: "project",
    proposals: "proposal",
    questions: "question",
    requirements: "requirement",
    resources: "resource",
    results: "result",
    reviews: "review",
    risks: "risk",
    schedules: "schedule",
    stories: "story",
    summaries: "summary",
    systems: "system",
    tasks: "task",
    technologies: "technology",
    updates: "update",
    users: "user",
    values: "value",
    versions: "version",
    women: "woman"
  };

  if (irregulars[word]) {
    return irregulars[word];
  }

  const original = word;

  if (word.endsWith("ies") && word.length > 4) {
    return `${word.slice(0, -3)}y`;
  }

  if (word.endsWith("es") && word.length > 4) {
    const candidate = word.slice(0, -2);
    if (
      /(ches|shes|sses|xes|zes|oes)$/.test(word) ||
      meaningDictionary[candidate] ||
      ipaDictionary[candidate]
    ) {
      return candidate;
    }
  }

  if (word.endsWith("s") && word.length > 3 && !word.endsWith("ss")) {
    const singular = word.slice(0, -1);
    if (meaningDictionary[singular] || ipaDictionary[singular] || !/[us]$/.test(singular)) {
      return singular;
    }
  }

  if (word.endsWith("ied") && word.length > 4) {
    return `${word.slice(0, -3)}y`;
  }

  if (word.endsWith("ed") && word.length > 4) {
    const base = word.slice(0, -2);
    const withE = `${base}e`;
    if (meaningDictionary[base] || ipaDictionary[base]) {
      return base;
    }
    if (meaningDictionary[withE] || ipaDictionary[withE]) {
      return withE;
    }
    if (/([b-df-hj-np-tv-z])\1$/.test(base)) {
      return base.slice(0, -1);
    }
    return base;
  }

  if (word.endsWith("ing") && word.length > 5) {
    const base = word.slice(0, -3);
    const withE = `${base}e`;
    if (meaningDictionary[base] || ipaDictionary[base]) {
      return base;
    }
    if (meaningDictionary[withE] || ipaDictionary[withE]) {
      return withE;
    }
    if (/([b-df-hj-np-tv-z])\1$/.test(base)) {
      return base.slice(0, -1);
    }
    return base;
  }

  if (word.endsWith("er") && word.length > 4) {
    const base = word.slice(0, -2);
    if (meaningDictionary[base] || ipaDictionary[base]) {
      return base;
    }
  }

  return original;
}

async function enrichMeaningsOnline(extraction, options) {
  const targets = [
    ...extraction.words
      .filter((item) => item.meaning === "待补充释义")
      .map((item) => attachType(item, "word")),
    ...extraction.phrases
      .filter((item) => item.meaning === "待补充释义")
      .map((item) => attachType(item, "phrase"))
  ].slice(0, 30);

  for (const item of targets) {
    const term = item.type === "word" ? item.word : item.phrase;
    const cacheKey = `${options.provider}:${term}:${options.translationEndpoint}`;
    if (onlineMeaningCache.has(cacheKey)) {
      applyOnlineResult(item, onlineMeaningCache.get(cacheKey));
      continue;
    }

    try {
      const onlineResult = await lookupMeaningOnline(term, item.type, options);
      onlineMeaningCache.set(cacheKey, onlineResult);
      applyOnlineResult(item, onlineResult);
    } catch (error) {
      onlineMeaningCache.set(cacheKey, null);
    }
  }
}

function applyOnlineResult(item, result) {
  if (!result) {
    return;
  }

  if (result.meaning) {
    item.meaning = result.meaning;
  }

  if (result.ipa && item.type === "word") {
    item.ipa = result.ipa;
  }
}

async function lookupMeaningOnline(term, type, options) {
  if (options.provider === "dictionaryapi") {
    if (type !== "word") {
      return null;
    }
    const dictionaryResult = await lookupViaDictionaryApi(term);
    return dictionaryResult
      ? {
          ipa: dictionaryResult.ipa || "",
          meaning: "待补充释义"
        }
      : null;
  }

  if (options.provider === "mymemory") {
    return lookupViaMyMemory(term, options);
  }

  if (options.provider === "google") {
    return lookupViaGoogle(term, options);
  }

  if (options.provider === "libretranslate") {
    return lookupViaTranslation(term, options);
  }

  const dictionaryResult = type === "word" ? await lookupViaDictionaryApi(term) : null;
  if (dictionaryResult?.definition) {
    const translatedDefinition = await translateText(dictionaryResult.definition, {
      ...options,
      provider: "mymemory"
    });
    return {
      ipa: dictionaryResult.ipa || "",
      meaning: translatedDefinition || "待补充释义"
    };
  }

  return lookupViaMyMemory(term);
}

async function lookupViaDictionaryApi(term) {
  const response = await fetch(
    `https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(lemmatizeWord(term.toLowerCase()))}`
  );
  if (!response.ok) {
    return null;
  }

  const payload = await response.json();
  const entry = payload[0];
  if (!entry) {
    return null;
  }

  const phonetic =
    entry.phonetic ||
    entry.phonetics?.find((item) => item.text)?.text ||
    "";
  const definition =
    entry.meanings?.[0]?.definitions?.[0]?.definition ||
    "";

  return {
    ipa: phonetic ? normalizeOnlineIpa(phonetic) : "",
    definition: definition || ""
  };
}

async function lookupViaTranslation(term, options) {
  const translated = await translateText(term, options);
  return translated
    ? { meaning: translated }
    : null;
}

async function translateText(text, options) {
  if (options.provider === "mymemory") {
    return translateViaMyMemory(text);
  }

  if (options.provider === "google") {
    return translateViaGoogle(text, options);
  }

  const endpoint = options.translationEndpoint || "https://libretranslate.com/translate";
  const payload = {
    q: text,
    source: "en",
    target: "zh",
    format: "text"
  };

  if (options.apiKey) {
    payload.api_key = options.apiKey;
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  if (!response.ok) {
    return "";
  }

  const data = await response.json();
  return typeof data.translatedText === "string" ? data.translatedText.trim() : "";
}

async function lookupViaMyMemory(term) {
  const translated = await translateViaMyMemory(term);
  return translated ? { meaning: translated } : null;
}

async function lookupViaGoogle(term, options) {
  const translated = await translateViaGoogle(term, options);
  return translated ? { meaning: translated } : null;
}

async function translateViaMyMemory(text) {
  const response = await fetch(
    `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=en|zh-CN`
  );

  if (!response.ok) {
    return "";
  }

  const data = await response.json();
  return typeof data.responseData?.translatedText === "string"
    ? data.responseData.translatedText.trim()
    : "";
}

async function translateViaGoogle(text, options) {
  if (!options.apiKey) {
    return "";
  }

  const endpoint =
    options.translationEndpoint ||
    "https://translation.googleapis.com/language/translate/v2";
  const response = await fetch(`${endpoint}?key=${encodeURIComponent(options.apiKey)}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      q: text,
      source: "en",
      target: "zh-CN",
      format: "text"
    })
  });

  if (!response.ok) {
    return "";
  }

  const data = await response.json();
  return typeof data.data?.translations?.[0]?.translatedText === "string"
    ? data.data.translations[0].translatedText.trim()
    : "";
}

function attachType(item, type) {
  item.type = type;
  return item;
}

function syncOnlineProviderFields() {
  const provider = onlineProvider.value;
  if (provider === "google") {
    translationEndpoint.value = "https://translation.googleapis.com/language/translate/v2";
    translationEndpoint.placeholder = "Google Cloud Translation 官方端点";
    translationApiKey.placeholder = "填写 Google Cloud API Key";
    return;
  }

  if (provider === "libretranslate") {
    translationEndpoint.value = "https://libretranslate.com/translate";
    translationEndpoint.placeholder = "例如：http://内网地址:5000/translate";
    translationApiKey.placeholder = "LibreTranslate / DeepL 等需要时填写";
    return;
  }

  if (provider === "mymemory") {
    translationEndpoint.value = "";
    translationEndpoint.placeholder = "MyMemory 使用内置公共接口，无需填写";
    translationApiKey.placeholder = "MyMemory 无需 API Key";
    return;
  }

  if (provider === "dictionaryapi") {
    translationEndpoint.value = "";
    translationEndpoint.placeholder = "Free Dictionary API 无需填写";
    translationApiKey.placeholder = "Free Dictionary API 无需 API Key";
    return;
  }

  translationEndpoint.value = "";
  translationEndpoint.placeholder = "组合模式默认使用 Free Dictionary + MyMemory";
  translationApiKey.placeholder = "组合模式默认无需 API Key";
}

function normalizeOnlineIpa(phonetic) {
  if (!phonetic) {
    return "";
  }

  return phonetic.startsWith("/") ? phonetic : `/${phonetic}/`;
}

function collectContext(tokens, index, size = 1) {
  const start = Math.max(0, index - 3);
  const end = Math.min(tokens.length, index + size + 3);
  return tokens.slice(start, end).join(" ");
}

function pushContext(targetMap, key, value) {
  if (!value) {
    return;
  }

  const current = targetMap.get(key) || [];
  if (!current.includes(value) && current.length < 3) {
    current.push(value);
  }
  targetMap.set(key, current);
}

function guessIpa(word) {
  let value = word.toLowerCase();

  const exactRules = [
    [/^one$/g, "wʌn"],
    [/^once$/g, "wʌns"],
    [/^two$/g, "tu"],
    [/^use$/g, "juz"],
    [/^used$/g, "juzd"],
    [/^user$/g, "juzər"]
  ];
  exactRules.forEach(([pattern, replacement]) => {
    value = value.replace(pattern, replacement);
  });

  const replacements = [
    [/tion\b/g, "ʃən"],
    [/sion\b/g, "ʒən"],
    [/cian\b/g, "ʃən"],
    [/tial\b/g, "ʃəl"],
    [/ture\b/g, "tʃər"],
    [/sure\b/g, "ʒər"],
    [/dge/g, "dʒ"],
    [/gue\b/g, "ɡ"],
    [/mb\b/g, "m"],
    [/kn/g, "n"],
    [/wr/g, "r"],
    [/alk\b/g, "ɔk"],
    [/all\b/g, "ɔl"],
    [/ough/g, "oʊ"],
    [/eigh/g, "eɪ"],
    [/igh/g, "aɪ"],
    [/ph/g, "f"],
    [/sh/g, "ʃ"],
    [/ch/g, "tʃ"],
    [/th/g, "θ"],
    [/wh/g, "w"],
    [/ck/g, "k"],
    [/ng/g, "ŋ"],
    [/qu/g, "kw"],
    [/ee/g, "i"],
    [/ea/g, "i"],
    [/oo/g, "u"],
    [/ou/g, "aʊ"],
    [/ow/g, "oʊ"],
    [/ew/g, "ju"],
    [/au/g, "ɔ"],
    [/aw/g, "ɔ"],
    [/ai/g, "eɪ"],
    [/ay/g, "eɪ"],
    [/oi/g, "ɔɪ"],
    [/oy/g, "ɔɪ"],
    [/ar/g, "ɑr"],
    [/er/g, "ər"],
    [/ir/g, "ər"],
    [/or/g, "ɔr"],
    [/ur/g, "ər"],
    [/ing\b/g, "ɪŋ"],
    [/ed\b/g, "d"],
    [/es\b/g, "z"],
    [/ly\b/g, "li"],
    [/ment\b/g, "mənt"],
    [/ness\b/g, "nəs"],
    [/less\b/g, "ləs"],
    [/ful\b/g, "fəl"],
    [/able\b/g, "əbəl"],
    [/ible\b/g, "əbəl"],
    [/ous\b/g, "əs"],
    [/ive\b/g, "ɪv"],
    [/ize\b/g, "aɪz"],
    [/ise\b/g, "aɪz"],
    [/ate\b/g, "eɪt"],
    [/ism\b/g, "ɪzəm"],
    [/ary\b/g, "eri"],
    [/ery\b/g, "eri"]
  ];

  replacements.forEach(([pattern, replacement]) => {
    value = value.replace(pattern, replacement);
  });

  value = value
    .replace(/([^aeiou])le\b/g, "$1əl")
    .replace(/c(?=[eiy])/g, "s")
    .replace(/c/g, "k")
    .replace(/g(?=[eiy])/g, "dʒ")
    .replace(/x/g, "ks")
    .replace(/y\b/g, "i");

  if (value.endsWith("e") && !/[əaeiou]e$/.test(value)) {
    value = value.slice(0, -1);
  }

  const singleLetterMap = {
    a: "æ",
    b: "b",
    d: "d",
    e: "ɛ",
    f: "f",
    h: "h",
    i: "ɪ",
    j: "dʒ",
    k: "k",
    l: "l",
    m: "m",
    n: "n",
    o: "ɑ",
    p: "p",
    q: "k",
    r: "r",
    s: "s",
    t: "t",
    u: "ʌ",
    v: "v",
    w: "w",
    y: "j",
    z: "z"
  };

  value = [...value]
    .map((char) => singleLetterMap[char] || char)
    .join("");

  return addPrimaryStress(value);
}

function addPrimaryStress(ipa) {
  if (ipa.startsWith("ˈ") || ipa.length <= 3) {
    return ipa;
  }

  const vowelMatches = [...ipa.matchAll(/[æɛɪɑʌəiuɔaɪoʊaʊɔɪ]+/g)];
  if (vowelMatches.length <= 1) {
    return `ˈ${ipa}`;
  }

  const firstVowelIndex = vowelMatches[0].index || 0;
  return `${ipa.slice(0, firstVowelIndex)}ˈ${ipa.slice(firstVowelIndex)}`;
}
