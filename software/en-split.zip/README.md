# 英文单词与短语提取器

这是一个可直接放在内网使用的静态网页应用，可离线运行；词典已拆分为独立 JSON 文件，便于继续扩容。

## 功能

- 上传 `txt` 会议记录文件
- 直接粘贴英文文本
- 提取英文单词并统计词频
- 提取重复出现的英文短语（2-3 词）
- 尽量输出音标
- 一键复制结果
- 一键下载结果为 `txt`

## 使用方式

由于离线词典改成了独立 JSON 文件，建议通过静态文件服务访问，而不是直接双击打开 `index.html`。最简单的方式是在当前目录启动一个静态文件服务：

```bash
python3 -m http.server 8080
```

然后访问：

```text
http://<你的内网IP>:8080
```

## 音标说明

音标采用两层策略：

1. 内置常见会议/业务词汇音标词典
2. 对未命中的单词使用离线规则近似生成音标

因此：

- 常见词准确率较高
- 生僻词、专有名词、人名、缩写词可能只提供近似读音

如果你后续希望把音标准确率再提高，可以继续扩展 [data/ipa-dictionary.json](./data/ipa-dictionary.json)。

当前已补充较多会议、业务、项目管理、产品、研发相关高频词。新增词条时建议统一使用：

```json
"word": "/ipa/"
```

例如：

```json
"meeting": "/ˈmitɪŋ/"
```

## 词典结构

- [data/dictionary-manifest.json](./data/dictionary-manifest.json): 词典清单
- [data/ipa-dictionary.json](./data/ipa-dictionary.json): 音标词典
- [data/meaning-dictionary.json](./data/meaning-dictionary.json): 单词释义词典
- [data/phrase-meaning-dictionary.json](./data/phrase-meaning-dictionary.json): 短语释义词典

这套结构适合继续扩展到 `10MB+` 规模。后续如果词典继续膨胀，建议再按字母、领域或频次拆成多份 JSON 分片。

## 在线翻译

当前支持：

- `MyMemory` 公共接口
- `Google Cloud Translation API`
- `LibreTranslate` 兼容接口
- `Free Dictionary API` 单词音标补充

说明：

- `Google Cloud Translation API` 需要官方 API Key
- 纯静态前端直接调用 Google API 会暴露 Key，更推荐内网代理或后端转发
- `LibreTranslate` 公共站点通常需要 API Key，自建兼容服务更适合内网
