#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

python3 -m venv .venv
. .venv/bin/activate

python -m pip install --upgrade pip
pip install -r requirements.txt

if ! python -m spacy download en_core_web_sm; then
  echo "spaCy model download failed, retrying once with no cache..."
  if ! python -m pip install --no-cache-dir https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl; then
    echo "Warning: en_core_web_sm install failed. The app can still run with regex tokenization."
  fi
fi

python -m nltk.downloader wordnet omw-1.4

echo "Setup complete."
echo "Run: APP_PORT=8000 .venv/bin/python app.py"
