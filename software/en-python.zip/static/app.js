const form = document.getElementById("analyze-form");
const statusNode = document.getElementById("status");
const summaryNode = document.getElementById("summary");
const wordsNode = document.getElementById("words");
const phrasesNode = document.getElementById("phrases");
const copyBtn = document.getElementById("copy-btn");
const downloadBtn = document.getElementById("download-btn");

let latestExportText = "";

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  statusNode.textContent = "分析中...";

  const formData = new FormData(form);
  try {
    const response = await fetch("/analyze", {
      method: "POST",
      body: formData,
    });
    const payload = await response.json();

    if (!response.ok) {
      throw new Error(payload.error || "分析失败");
    }

    latestExportText = payload.export_text || "";
    renderSummary(payload.summary);
    renderWords(payload.words);
    renderPhrases(payload.phrases);
    statusNode.textContent = "分析完成。";
  } catch (error) {
    latestExportText = "";
    summaryNode.innerHTML = '<div class="empty">暂无结果</div>';
    wordsNode.innerHTML = '<div class="empty">暂无结果</div>';
    phrasesNode.innerHTML = '<div class="empty">暂无结果</div>';
    statusNode.textContent = error.message;
  }
});

copyBtn.addEventListener("click", async () => {
  if (!latestExportText) {
    statusNode.textContent = "没有可复制的结果。";
    return;
  }
  try {
    await navigator.clipboard.writeText(latestExportText);
    statusNode.textContent = "结果已复制到剪贴板。";
  } catch {
    statusNode.textContent = "复制失败，请检查浏览器权限。";
  }
});

downloadBtn.addEventListener("click", () => {
  if (!latestExportText) {
    statusNode.textContent = "没有可下载的结果。";
    return;
  }
  const blob = new Blob([latestExportText], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "analysis-result.txt";
  anchor.click();
  URL.revokeObjectURL(url);
  statusNode.textContent = "TXT 已下载。";
});

function renderSummary(summary) {
  const items = [
    ["总词数", summary.total_words],
    ["去重词数", summary.unique_words],
    ["词汇密度", summary.lexical_density],
    ["IPA", summary.ipa_enabled ? "已启用" : "未启用"],
    ["spaCy", summary.spacy_enabled ? "已启用" : "未启用"],
    ["中文语义", summary.semantic_enabled ? "已启用" : "未启用"],
  ];

  summaryNode.innerHTML = items
    .map(
      ([label, value]) => `
        <div class="metric">
          <div class="label">${label}</div>
          <div class="value">${value}</div>
        </div>
      `
    )
    .join("");
}

function renderWords(words) {
  if (!words.length) {
    wordsNode.innerHTML = '<div class="empty">暂无结果</div>';
    return;
  }
  wordsNode.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>单词</th>
          <th>音标</th>
          <th>中文语义</th>
          <th>频次</th>
        </tr>
      </thead>
      <tbody>
        ${words
          .map(
            (item) => `
              <tr>
                <td>${escapeHtml(item.word)}</td>
                <td>${escapeHtml(item.ipa ? `[${item.ipa}]` : "-")}</td>
                <td>${escapeHtml(item.meaning_zh || "-")}</td>
                <td>${item.count}</td>
              </tr>
            `
          )
          .join("")}
      </tbody>
    </table>
  `;
}

function renderPhrases(phrases) {
  if (!phrases.length) {
    phrasesNode.innerHTML = '<div class="empty">未检测到重复短语</div>';
    return;
  }
  phrasesNode.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>短语</th>
          <th>中文语义</th>
          <th>频次</th>
        </tr>
      </thead>
      <tbody>
        ${phrases
          .map(
            (item) => `
              <tr>
                <td>${escapeHtml(item.phrase)}</td>
                <td>${escapeHtml(item.meaning_zh || "-")}</td>
                <td>${item.count}</td>
              </tr>
            `
          )
          .join("")}
      </tbody>
    </table>
  `;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
