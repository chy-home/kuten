# English Frequency Analyzer

可直接部署在内网、支持离线运行的英文文本分析工具。

## 功能

- 上传 `txt` 会议记录文件
- 直接粘贴英文文本
- 提取英文单词并统计词频
- 提取重复出现的英文短语（2-3 词）
- 尽量输出音标
- 追加中文语义列
- 一键复制结果
- 一键下载结果为 `txt`

## 技术方案

- Web 框架：`Flask`
- 音标：优先 `cmudict + ARPABET -> IPA`，未安装时退回 `eng-to-ipa`
- 分词：优先 `spaCy + en_core_web_sm`，未安装模型时自动退回正则分词
- 短语提取：基于本地规则的 2-3 gram 重复统计
- 中文语义：`NLTK WordNet + OMW` 离线查询中文同义词
- 服务启动：优先 `waitress`，默认监听 `0.0.0.0:8000`

## 本地运行

推荐直接执行：

```bash
chmod +x setup_m1.sh
./setup_m1.sh
APP_PORT=8000 .venv/bin/python app.py
```

如果你想手动安装，也可以按下面执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python -m nltk.downloader wordnet omw-1.4
APP_PORT=8000 python app.py
```

浏览器打开：

- 本机访问：`http://127.0.0.1:8000`
- 局域网访问：`http://你的机器IP:8000`

如需改端口：

```bash
APP_PORT=9000 python app.py
```

## 离线部署说明

如果目标环境无法联网，建议在可联网机器先下载以下 wheel / 模型，再拷贝到内网：

1. `Flask`
2. `eng-to-ipa`
3. `cmudict`
4. `spaCy`
5. `NLTK`
6. `wordnet`
7. `omw-1.4`
8. `en_core_web_sm`

安装完后，本项目不依赖外部 API，可完全离线运行。部署到内网机器时，确保系统防火墙放行对应端口。

如果 `en_core_web_sm` 无法下载，应用仍可运行，只是会自动降级为正则分词，分析精度会比 `spaCy` 低一些。

## Apple Silicon / M1

已避免使用与架构强绑定的代码路径，目录可直接复制到 M1 / M2 / M3 MacBook。

推荐在目标机器执行：

```bash
chmod +x setup_m1.sh
./setup_m1.sh
APP_PORT=8000 .venv/bin/python app.py
```

脚本会自动创建 `.venv`、安装依赖、下载 `spaCy` 模型和 `NLTK` 语料；如果 `spaCy` 模型下载失败，程序仍可降级运行。

## 常见问题

### 1. `Address already in use`

说明默认端口已被占用。直接换端口启动：

```bash
APP_PORT=9000 .venv/bin/python app.py
```

### 2. `Wheel 'en-core-web-sm' ... is invalid`

这是 `spaCy` 模型下载不完整或缓存损坏。可直接重跑：

```bash
./setup_m1.sh
```

脚本会自动重试一次；如果仍失败，应用会降级运行，不会阻塞主功能。

### 3. 终端显示 `Serving on http://0.0.0.0:8000`

这表示服务已经启动成功。

- 当前机器打开：`http://127.0.0.1:8000`
- 局域网其他机器打开：`http://你的机器IP:8000`

## 可选增强

### 更准的音标

可加入 `cmudict` 和自定义 ARPABET -> IPA 映射表，替换当前 `eng-to-ipa` 的默认结果。

### 离线翻译

可选接入以下本地模型：

- `Helsinki-NLP/opus-mt-en-zh`
- 本地 `transformers` 推理

建议把翻译做成单独开关，避免影响基础分析速度。
