# AGENTS

## Project Summary

This project is an offline-capable internal web app for English text analysis.

Core capabilities:

- Upload a `txt` meeting record file
- Paste English text directly
- Extract English words and word frequencies
- Extract repeated 2-3 word phrases
- Show IPA pronunciation when available
- Show Chinese semantic hints
- Copy results with one click
- Download results as `txt`

## Runtime

- Python app entry: `app.py`
- Analysis logic: `analyzer.py`
- Frontend: `templates/index.html`, `static/app.js`, `static/styles.css`
- Default host: `0.0.0.0`
- Default port: `8000`

Start locally:

```bash
APP_PORT=8000 .venv/bin/python app.py
```

Access:

- Local machine: `http://127.0.0.1:8000`
- LAN: `http://<machine-ip>:8000`

If port `8000` is occupied, override it:

```bash
APP_PORT=9000 .venv/bin/python app.py
```

## Dependency Notes

Primary dependencies:

- `Flask`
- `waitress`
- `cmudict`
- `eng-to-ipa`
- `spaCy`
- `nltk`

Optional but preferred NLP assets:

- `en_core_web_sm`
- `wordnet`
- `omw-1.4`

## Analysis Behavior

### IPA

IPA generation is already implemented.

Priority order:

1. `cmudict`
2. custom `ARPABET -> IPA` mapping
3. fallback to `eng_to_ipa`

Relevant code:

- `ARPABET_TO_IPA`
- `_load_cmudict()`
- `_arpabet_to_ipa()`
- `ipa_for_word()`

### Chinese semantics

Chinese semantic hints are generated offline.

Priority order:

1. local fallback dictionary for common function words and product terms
2. `WordNet + OMW` lookup
3. phrase decomposition fallback

Relevant code:

- `FALLBACK_ZH`
- `zh_semantic_for_term()`
- `_fallback_semantic()`
- `_singularize()`

### Tokenization

Priority order:

1. `spaCy` with `en_core_web_sm`
2. regex fallback

If `en_core_web_sm` installation fails, the app must still run with regex tokenization.

## Setup

Recommended setup on macOS or Apple Silicon:

```bash
chmod +x setup_m1.sh
./setup_m1.sh
```

The setup script:

- creates `.venv`
- installs Python dependencies
- downloads `en_core_web_sm`
- downloads `wordnet` and `omw-1.4`
- tolerates `spaCy` model download failure and keeps the app usable

## Operational Notes

- This app is intended for intranet or offline deployment.
- Do not add mandatory external API dependencies for core analysis.
- Keep offline fallback behavior intact.
- If updating startup instructions, keep them aligned with port `8000` unless the code changes.
- If editing IPA or semantic logic, preserve deterministic offline behavior.
