#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

export NLTK_DATA="${NLTK_DATA:-$ROOT_DIR/nltk_data}"
export APP_PORT="${APP_PORT:-8000}"

.venv/bin/python app.py
