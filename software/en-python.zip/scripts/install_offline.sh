#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

python3 -m venv .venv
. .venv/bin/activate

python -m pip install --upgrade pip
pip install --no-index --find-links wheelhouse -r requirements.txt
pip install --no-index --find-links wheelhouse en-core-web-sm==3.8.0

mkdir -p "$ROOT_DIR/nltk_data"
cp -R vendor/nltk_data/. "$ROOT_DIR/nltk_data/"

echo "Offline install complete."
echo "Run: NLTK_DATA=$ROOT_DIR/nltk_data APP_PORT=8000 .venv/bin/python app.py"
