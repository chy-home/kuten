# Offline Bundle

This bundle is intended for offline deployment on a compatible macOS machine.

Compatibility of the bundle generated from this workspace:

- macOS
- x86_64
- Python 3.13

If the target machine has a different architecture, rebuild the wheelhouse on that target architecture first.

## Install

```bash
chmod +x scripts/install_offline.sh scripts/run_offline.sh
./scripts/install_offline.sh
```

## Run

```bash
./scripts/run_offline.sh
```

Default URL:

- `http://127.0.0.1:8000`

Override port if needed:

```bash
APP_PORT=9000 ./scripts/run_offline.sh
```

## Notes

- `NLTK_DATA` is bundled under `vendor/nltk_data` and copied into `nltk_data` during install.
- `en_core_web_sm` is installed from the local `wheelhouse`.
- No internet access is required after the wheelhouse has been prepared.
