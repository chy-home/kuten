from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, jsonify, render_template, request

from analyzer import AnalysisError, analyze_text, build_export_text


BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__, template_folder=str(BASE_DIR / "templates"), static_folder=str(BASE_DIR / "static"))


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/analyze")
def analyze():
    uploaded = request.files.get("file")
    text_input = request.form.get("text", "").strip()

    content = text_input
    if uploaded and uploaded.filename:
        content = uploaded.read().decode("utf-8", errors="ignore")

    try:
        result = analyze_text(content)
    except AnalysisError as exc:
        return jsonify({"error": str(exc)}), 400

    result["export_text"] = build_export_text(result)
    return jsonify(result)


if __name__ == "__main__":
    host = os.getenv("APP_HOST", "0.0.0.0")
    port = int(os.getenv("APP_PORT", "8000"))

    try:
        from waitress import serve
    except ImportError:
        app.run(host=host, port=port, debug=False)
    else:
        print(f"Serving on http://{host}:{port}")
        serve(app, host=host, port=port)
