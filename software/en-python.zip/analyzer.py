from __future__ import annotations

import re
import warnings
from collections import Counter
from typing import Iterable


WORD_RE = re.compile(r"[A-Za-z]+(?:'[A-Za-z]+)?")

STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "he",
    "in",
    "is",
    "it",
    "its",
    "of",
    "on",
    "that",
    "the",
    "to",
    "was",
    "were",
    "will",
    "with",
}


class AnalysisError(ValueError):
    pass


try:
    import eng_to_ipa as ipa_engine
except Exception:  # pragma: no cover
    ipa_engine = None

try:
    import cmudict
except Exception:  # pragma: no cover
    cmudict = None

try:
    import spacy
except Exception:  # pragma: no cover
    spacy = None

try:
    from nltk.corpus import wordnet as wn
except Exception:  # pragma: no cover
    wn = None


_NLP = None
_CMU_DICT = None
_WORDNET_READY = None
FALLBACK_ZH = {
    "we": "我们",
    "our": "我们的",
    "you": "你 / 你们",
    "your": "你的 / 你们的",
    "them": "他们 / 它们 / 她们",
    "they": "他们 / 它们 / 她们",
    "it": "它",
    "its": "它的",
    "he": "他",
    "she": "她",
    "i": "我",
    "me": "我",
    "us": "我们",
    "to": "到 / 去 / 用于",
    "of": "的 / 关于",
    "the": "定冠词",
    "a": "不定冠词",
    "an": "不定冠词",
    "and": "和 / 并且",
    "or": "或者 / 或",
    "but": "但是 / 但",
    "that": "那 / 该 / 用于引导从句",
    "this": "这 / 此",
    "these": "这些",
    "those": "那些",
    "with": "和 / 使用 / 带有",
    "without": "没有 / 不带",
    "along": "沿着 / 一起",
    "also": "也 / 另外",
    "primarily": "主要地 / 首先",
    "may": "可能 / 可以",
    "can": "能够 / 可以",
    "will": "将会 / 会",
    "would": "将 / 会 / 愿意",
    "should": "应该",
    "could": "可以 / 能够",
    "are": "是",
    "is": "是",
    "was": "是 / 当时处于",
    "were": "是 / 当时处于",
    "be": "是 / 成为",
    "being": "正在 / 处于",
    "been": "已经 / 曾经",
    "use": "使用 / 用途",
    "user": "用户 / 使用者",
    "users": "用户 / 使用者",
    "cookie": "Cookie / 浏览器标识 / 小型文本文件",
    "cookies": "Cookies / 浏览器标识 / 小型文本文件",
    "website": "网站",
    "websites": "网站",
    "advert": "广告",
    "adverts": "广告",
    "advertisement": "广告",
    "advertisements": "广告",
    "interest": "兴趣 / 关注 / 利益",
    "interests": "兴趣 / 关注 / 利益",
    "experience": "体验 / 经验",
    "efficiency": "效率",
    "technology": "技术",
    "technologies": "技术 / 科技",
}
ARPABET_TO_IPA = {
    "AA": "a",
    "AE": "ae",
    "AH": "ah",
    "AO": "aw",
    "AW": "au",
    "AY": "ai",
    "B": "b",
    "CH": "tʃ",
    "D": "d",
    "DH": "ð",
    "EH": "e",
    "ER": "er",
    "EY": "ei",
    "F": "f",
    "G": "g",
    "HH": "h",
    "IH": "i",
    "IY": "iː",
    "JH": "dʒ",
    "K": "k",
    "L": "l",
    "M": "m",
    "N": "n",
    "NG": "ŋ",
    "OW": "ou",
    "OY": "ɔi",
    "P": "p",
    "R": "r",
    "S": "s",
    "SH": "ʃ",
    "T": "t",
    "TH": "θ",
    "UH": "u",
    "UW": "uː",
    "V": "v",
    "W": "w",
    "Y": "j",
    "Z": "z",
    "ZH": "ʒ",
}


def _load_spacy():
    global _NLP
    if _NLP is not None:
        return _NLP
    if spacy is None:
        return None
    try:
        _NLP = spacy.load("en_core_web_sm", disable=["ner", "parser", "lemmatizer"])
    except Exception:
        _NLP = None
    return _NLP


def _load_cmudict():
    global _CMU_DICT
    if _CMU_DICT is not None:
        return _CMU_DICT
    if cmudict is None:
        return None
    try:
        _CMU_DICT = cmudict.dict()
    except Exception:
        _CMU_DICT = None
    return _CMU_DICT


def _load_wordnet():
    global _WORDNET_READY
    if _WORDNET_READY is not None:
        return _WORDNET_READY
    if wn is None:
        _WORDNET_READY = False
        return _WORDNET_READY
    try:
        wn.synsets("test")
        _WORDNET_READY = True
    except LookupError:
        _WORDNET_READY = False
    return _WORDNET_READY


def _tokenize_with_spacy(text: str) -> list[str]:
    nlp = _load_spacy()
    if nlp is None:
        return []
    doc = nlp(text)
    return [token.text.lower() for token in doc if token.is_alpha]


def _tokenize_with_regex(text: str) -> list[str]:
    return [match.group(0).lower() for match in WORD_RE.finditer(text)]


def tokenize(text: str) -> list[str]:
    tokens = _tokenize_with_spacy(text)
    return tokens or _tokenize_with_regex(text)


def normalize_phrase_tokens(tokens: Iterable[str]) -> list[str]:
    return [token.lower() for token in tokens if token and token.isalpha()]


def ipa_for_word(word: str) -> str:
    if not word:
        return ""
    cmu_dict = _load_cmudict()
    if cmu_dict:
        pronunciations = cmu_dict.get(word.lower())
        if pronunciations:
            return _arpabet_to_ipa(pronunciations[0])
    if ipa_engine is None:
        return ""
    try:
        ipa = ipa_engine.convert(word)
    except Exception:
        return ""
    cleaned = ipa.replace("*", "").strip()
    if cleaned == word.lower():
        return ""
    return cleaned


def _arpabet_to_ipa(phones: list[str]) -> str:
    parts = []
    for phone in phones:
        normalized = re.sub(r"\d", "", phone)
        parts.append(ARPABET_TO_IPA.get(normalized, normalized.lower()))
    return "".join(parts)


def zh_semantic_for_term(term: str) -> str:
    if not term or not _load_wordnet():
        return _fallback_semantic(term)

    normalized = term.strip().lower().replace(" ", "_")
    fallback = _fallback_semantic(term)
    if fallback:
        return fallback

    synsets = wn.synsets(normalized)
    if not synsets and "_" not in normalized:
        synsets = wn.synsets(normalized, pos=wn.NOUN)
    if not synsets and "_" not in normalized:
        morphy = wn.morphy(normalized)
        if morphy and morphy != normalized:
            synsets = wn.synsets(morphy)

    for synset in synsets:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            lemmas = synset.lemma_names("cmn")
        if lemmas:
            cleaned = []
            for lemma in lemmas[:3]:
                normalized_lemma = lemma.replace("_", " ").replace("+", "")
                if normalized_lemma not in cleaned:
                    cleaned.append(normalized_lemma)
            return " / ".join(cleaned)

    if "_" in normalized:
        parts = [zh_semantic_for_term(part) for part in normalized.split("_")]
        joined = " / ".join(part for part in parts if part)
        return joined.strip()

    return fallback


def _fallback_semantic(term: str) -> str:
    normalized = term.strip().lower().replace("_", " ")
    if not normalized:
        return ""
    if normalized in FALLBACK_ZH:
        return FALLBACK_ZH[normalized]

    if " " in normalized:
        parts = [_fallback_semantic(part) for part in normalized.split()]
        parts = [part for part in parts if part]
        return " / ".join(parts)

    singular = _singularize(normalized)
    if singular != normalized and singular in FALLBACK_ZH:
        return FALLBACK_ZH[singular]

    return ""


def _singularize(word: str) -> str:
    if len(word) <= 3:
        return word
    if word.endswith("ies") and len(word) > 4:
        return word[:-3] + "y"
    if word.endswith("es") and len(word) > 3:
        return word[:-2]
    if word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def extract_word_stats(tokens: list[str], limit: int = 100) -> list[dict]:
    counter = Counter(tokens)
    results = []
    for word, count in counter.most_common(limit):
        results.append(
            {
                "word": word,
                "count": count,
                "ipa": ipa_for_word(word),
                "meaning_zh": zh_semantic_for_term(word),
            }
        )
    return results


def extract_repeated_phrases(tokens: list[str], limit: int = 100) -> list[dict]:
    phrase_counter: Counter[str] = Counter()
    clean_tokens = normalize_phrase_tokens(tokens)
    for size in (2, 3):
        for idx in range(len(clean_tokens) - size + 1):
            chunk = clean_tokens[idx : idx + size]
            if all(token in STOPWORDS for token in chunk):
                continue
            phrase_counter[" ".join(chunk)] += 1

    results = []
    for phrase, count in phrase_counter.most_common():
        if count < 2:
            continue
        results.append(
            {
                "phrase": phrase,
                "count": count,
                "meaning_zh": zh_semantic_for_term(phrase),
            }
        )
        if len(results) >= limit:
            break
    return results


def analyze_text(text: str) -> dict:
    if not text or not text.strip():
        raise AnalysisError("请输入英文文本或上传 txt 文件。")

    tokens = tokenize(text)
    if not tokens:
        raise AnalysisError("未识别到英文单词，请检查输入内容。")

    unique_words = len(set(tokens))
    total_words = len(tokens)
    lexical_density = round(unique_words / max(total_words, 1), 4)

    return {
        "summary": {
            "total_words": total_words,
            "unique_words": unique_words,
            "lexical_density": lexical_density,
            "spacy_enabled": _load_spacy() is not None,
            "ipa_enabled": _load_cmudict() is not None or ipa_engine is not None,
            "semantic_enabled": _load_wordnet(),
        },
        "words": extract_word_stats(tokens),
        "phrases": extract_repeated_phrases(tokens),
        "source_preview": text[:1000],
    }


def build_export_text(result: dict) -> str:
    summary = result["summary"]
    lines = [
        "English Text Analysis",
        "",
        f"Total Words: {summary['total_words']}",
        f"Unique Words: {summary['unique_words']}",
        f"Lexical Density: {summary['lexical_density']}",
        f"IPA Enabled: {'Yes' if summary['ipa_enabled'] else 'No'}",
        f"spaCy Enabled: {'Yes' if summary['spacy_enabled'] else 'No'}",
        f"Chinese Semantic Enabled: {'Yes' if summary['semantic_enabled'] else 'No'}",
        "",
        "Word Frequency",
    ]

    for item in result["words"]:
        ipa = f" [{item['ipa']}]" if item["ipa"] else ""
        meaning = f" | 中文: {item['meaning_zh']}" if item["meaning_zh"] else ""
        lines.append(f"{item['word']}{ipa}: {item['count']}{meaning}")

    lines.extend(["", "Repeated Phrases"])
    for item in result["phrases"]:
        meaning = f" | 中文: {item['meaning_zh']}" if item["meaning_zh"] else ""
        lines.append(f"{item['phrase']}: {item['count']}{meaning}")

    return "\n".join(lines)
